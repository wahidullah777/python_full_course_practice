touple=(("7,8,4,1",(78,987,678),("wahid")),(6,8,7,5),("wahid")),( "wahid")#touple mean unchangeable
print(touple)