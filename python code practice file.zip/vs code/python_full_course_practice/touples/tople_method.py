tup =(1,22,33,44,5,5,6,66,77)
tump=list(tup)
tump.pop(3)#sort ho jye gyi
print(tump)
tup=tuple(tump)
print(tup)