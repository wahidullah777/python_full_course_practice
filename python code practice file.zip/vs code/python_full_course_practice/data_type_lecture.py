a=7
b="wahid"
c=7.5 
d=True #TRUE MEAN HA OR FALSE MEAN NO
e=None # none mean null