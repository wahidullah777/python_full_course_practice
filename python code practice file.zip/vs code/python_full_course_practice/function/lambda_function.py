def avg(d):
   return d*2
print(avg(5))

#ye to ho gya na sim function hum jsy used karty hai

double = lambda d:d*2
print(double(5))