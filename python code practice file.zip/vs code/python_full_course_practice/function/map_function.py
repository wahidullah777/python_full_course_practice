def cube(s):
   return s*s*s
print(cube(2)) 
wahid=[1,2,3,4,5,6,7,8,9]
lis=list(map(cube,wahid))
print(lis)