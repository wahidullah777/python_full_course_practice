def filter_function(a):
   return a>4
new=list(filter(filter_function,wahid))
print(new)