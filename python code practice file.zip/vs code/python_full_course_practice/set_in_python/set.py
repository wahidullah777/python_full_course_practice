s={ 2,3,4,5,6,"wahid","wahid",6.8,6.8,7,5,4,5}
print(s)

s=set()  # empty set ko hum is tara show karty hai 
print(type(s))