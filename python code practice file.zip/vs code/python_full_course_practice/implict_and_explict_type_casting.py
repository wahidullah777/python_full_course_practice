a="4"
b="5"
# ye string ha or hum is ko integer ma convert karna chaty hai ha to ye kaam developer kud bi kars akta hai is ko hum explicit type kahty hai 

print(int(a)+int(b))

 #no 2 implict type casting
c=4.5
d=6
#agar ak num float hai or dosra interger hai to python is ko kuod hi change kar skta hai , python njo inter ma hai is ko float ma change kar ky is ko bi float bana dye ga
print(c+d)