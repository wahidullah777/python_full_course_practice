a=int(input("enter the age :" ))
if(a>18):
   print("your are drive")
else:
   print("your are not drive ")



# elif conditions

ab=int(input("enter the age :" ))
if(ab>18):
   print("your are drive")
elif(ab==18):
     print("you are the drive or not")
else:
      print("your are not drive ")

# nested if else conditons 
ab=int(input("enter the age :" ))
if(ab<0):
   print("your are drive")
elif(ab>0):
      if(ab<=10):
        print("you are the hfhfhfhfchj")
      elif(ab>10 and ab<=20):
            print("you")
      else:
            print(" youtumhhh")
         
   

else:
   print("your are not drive ")