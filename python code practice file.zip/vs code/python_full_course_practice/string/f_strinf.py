wahid="no"
wahidd="yes"
print(f"wahid is a bad boy{wahidd} and the best boys{wahid}")


val=0.897777
print(f"the value print first twwo decimal{val:.2f}") #2f mean first two decimal

print(type(f"{val:.2f}"))



print("wahid is a bad boy{wahidd} and the best boys{wahid}")
