wahid="wahid is a bad boy{0} and the best boys{1}"
wahidddd="no"
wahidd="yes"
print(wahid.format(wahidddd,wahidd))
