a=7
print("alllli")
print("wahidd")
print("ali",a)

# agar zyda line ma string hai to 
# 1 ..single thirple quotation or 
# 2..double thirple quqtation sa bi used kars akty hai
# 3. \n ka used bi kars akty hai next line ma jny ky lye 
apple= """wahid is a good boy
then nm\zkdj ksdn kanjda
adjad
hdisd
ajdhj
ajdsh
jdas sjdh jdh ajhg""" 
print(apple)

#string index number [0],[1],[2]
a="wahid"

print(a[0])
print(a[1])
print(a[2])
print(a[3])
print(a[4])

# agar koi bari string a jye to is ky lye hum kai akry os ky lye hum for lop kamistamal kary gye
print("\n")
for character in apple:
   print(character)