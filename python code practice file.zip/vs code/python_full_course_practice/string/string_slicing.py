a=" !!  wahidullah  !!!!!"
print(len(a))

print(a[0:11])
print(a[0:9])
print(a[-8:11])
print(a[-2:11])
