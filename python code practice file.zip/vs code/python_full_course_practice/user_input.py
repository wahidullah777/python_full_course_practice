x=input("enter your first number :")
y=input("enter your second  number :")
print ("addtion  hmber is  = " ,int(x)+int(y))