print(7+8) #addition
print(7-8) #substracton
print(7*8) #multiplication
print(7/8) #division
print(7%8) #reminder modulus
print(7//8) #floor division MEAN double division
print(7**8)


a=5
b=4
print("this value of ' a + b' = ",a+b)
print("this value of ' a - b' = ",a-b)
print("this value of ' a % b' = ",a%b)
print("this value of ' a / b' = ",a/b)
print("this value of ' a // b' = ",a//b)
print("this value of ' a ** b' = ",a**b)  
