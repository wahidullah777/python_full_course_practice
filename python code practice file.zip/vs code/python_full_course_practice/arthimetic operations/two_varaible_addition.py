print ( "Hello")
print(765)
print(True)
print(None)

a=7
print(a)

b=7
print(b)
print(a+b)

c="hello"
print(c)
print(a+b)