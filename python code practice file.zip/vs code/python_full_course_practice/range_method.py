for x in range(11):
   print("wahid") # range ma baty ga agar 5 ha to 0-4 tak jye gaa 
  # or 0-5 tak jan ha to x+1 kar dy gye  
print("\n")
for y in range(2,10):
   print(y)

print("\n")
for y in range(2,10,3):
   print(y)