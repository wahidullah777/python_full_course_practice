name= "wahid"
for i in name:
   print(i) # har ak chagactre ko print karta hai ak ak kar ka
   if(i=="a"):
      print("this is something")



      name = ["wahid","ali","ahmad","hassan"]
for name in name:
    print(name) # name used ho rha list ka element ko show karwny ky lye 
    for i in name:
       print(i)