for i in range(5):
   print(i)
else:
   print("this is the llop end")
