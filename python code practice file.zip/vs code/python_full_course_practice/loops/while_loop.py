i=0
while(i<5):
   print(i)
   i=i+1
   
   
   x=int(input("enter the number: "))
   while(x<100):
      x=int(input("enter the number: "))
      print(x)
   print("try again end the loop :") 


#decriment loop mtlb loop 10-1 tak chly gaaa
i =10
while(i>0):
   print(i)
   i=i-1
else :  #else tab chly ga jab loop 00 ho jye ga or loop falase ho ga to else condition chal jye gyi
   print("this is the end of loop")