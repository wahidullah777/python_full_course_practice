list =[8,2.3,4,4567,"wahid",[456,23456]],["apple","banana"] #list mean changeable
print(list)