list1=[1,2,3,4,5,6,7,8,9,10]
list1.append(11)  #list ma add kar dye ga 
print(list1)

list1.sort()#sort ho jye gyi
print(list1)

list1.reverse()
print(list1)

list1.insert(1,889)# index pr 899 ko insert karna 
print(list1)

list1.pop(0) #element pop karna  
print(list1)

list1.remove(1) #element remove karta hai
print(list1)



list1.copy() #copy bana dy ga
print(list1)


list1.count(2) # COUNT MEAN 2 kithni dafa a rha hai list ma
print(list1)

list1.clear() #full list claer kar dye ga
print(list1)

l=[111,222,33,4,4,444,4]
list1.extend(l)
print(list1) # mtlb ak new list ko is ky last ma add karna 


list1.index(1)  # index NUMBER DYE GA
print(list1)
