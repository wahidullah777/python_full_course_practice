print(7,8,9,10,sep="_",end="000000\n")
print ("hello world",7,"wahid")


print(7*8)
print('i am\'s\' \"good\" boy\n and alawys happy' )
#this is comment