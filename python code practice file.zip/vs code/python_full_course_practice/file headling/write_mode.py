f=open("myfile.txt","w")
f.write("hello wahid")
f.close