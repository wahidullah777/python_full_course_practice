f=open("myfile.txt","r")
text =f.read()
print(text)
f.close
