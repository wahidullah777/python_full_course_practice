f=open("myfile.txt","a")
f.write("hello wahid")
f.close