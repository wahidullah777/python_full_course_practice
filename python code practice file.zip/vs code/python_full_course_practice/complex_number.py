a=7
b="wahid"
c=7.5 
d=True #TRUE MEAN HA OR FALSE MEAN NO
e=None # none mean null
f=complex(2,4) #complex number
print("this is the type of",type(a))
print("this is the type of",type(b))
print("this is the type of",type(c))
print("this is the type of",type(d))
print("this is the type of",type(e))
print("this is the type of",type(f))
