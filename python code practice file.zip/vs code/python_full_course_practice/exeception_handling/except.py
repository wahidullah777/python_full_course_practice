try:
 n=int(input("enter the number :"))
 a=[3,4]
 print(a[n])
   
except:
 print("this is not interger value ")

