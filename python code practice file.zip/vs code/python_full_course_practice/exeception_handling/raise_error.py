n=int(input("enter the number : "))
if(n>5 or n>9):
   raise ValueError( "it is not the number of 5 and 9")