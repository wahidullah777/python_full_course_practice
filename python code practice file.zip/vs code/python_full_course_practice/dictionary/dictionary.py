dict={"name":"wahid","age":23,"city":"kasur"},{ "float": 7.8} #dict mean dictionary
print(dict)