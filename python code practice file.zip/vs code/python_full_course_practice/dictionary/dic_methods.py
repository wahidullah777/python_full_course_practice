dic1= {77:7,88:8,99:9,100:10}
dic2= {6:7,8:9,10:11,12:13}
dic1.update(dic2)
print(dic1)



dic1.pop(77)
print(dic1)


dic1.clear()
print(dic1)