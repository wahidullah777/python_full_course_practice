dxc={"wahid":7,"nasir":8,"ali":9,"hassan":10} # jo wahid hai wo key hai or jo (7) ha wo value hai ha wahid ki 
print(dxc)
print(dxc["wahid"]) # single print kar ky lye 
print(dxc["nasir"])
print(dxc["ali"])
print(dxc["hassan"])

print(dxc.keys()) # key show karne ky lye 
print(dxc.values())